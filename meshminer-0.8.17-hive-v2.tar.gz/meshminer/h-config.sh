#!/usr/bin/env bash
# HiveOS sources this file before h-run.sh. Generate MeshMiner's config immediately.
miner_ver() { echo "0.8.17"; }

miner_config_echo() {
  local config="${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/meshminer/meshminer.conf}"
  [[ -f "$config" ]] && cat "$config" || echo "MeshMiner config not generated"
}

miner_config_gen() {
  local config="${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/meshminer/meshminer.conf}"
  local pool="${CUSTOM_URL%%$'\n'*}"; pool="${pool%% *}"
  local user="${CUSTOM_TEMPLATE:-${CUSTOM_WALLET:-}}"
  local algo="${CUSTOM_ALGO:-v12}"
  local pass="${CUSTOM_PASS:-x}"
  local extra="${CUSTOM_USER_CONFIG//$'\n'/ }"
  local backend

  pool="${pool#stratum+tcp://}"; pool="${pool#stratum://}"; pool="${pool#tcp://}"
  [[ -z "$pool" ]] && { echo "MeshMiner: Pool URL is required" >&2; return 1; }
  [[ -z "$user" ]] && { echo "MeshMiner: Wallet/template is required" >&2; return 1; }

  # Expand common Hive placeholders if they are still present.
  [[ -n "${WAL:-}" ]] && user="${user//%WAL%/$WAL}"
  [[ -n "${EWAL:-}" ]] && user="${user//%EWAL%/$EWAL}"
  [[ -n "${DWAL:-}" ]] && user="${user//%DWAL%/$DWAL}"
  [[ -n "${ZWAL:-}" ]] && user="${user//%ZWAL%/$ZWAL}"
  [[ -n "${WORKER_NAME:-}" ]] && user="${user//%WORKER_NAME%/$WORKER_NAME}"

  case "${algo,,}" in
    lumenite|homescrypt|homescrypt-v12) algo=v12 ;;
    nonsense|fishhash) algo=fishhashplus ;;
    dragonchain) algo=yespower ;;
    plaine) algo=isochron ;;
    avian-x16rt) algo=x16rt ;;
    avian-minotaurx) algo=minotaurx ;;
    randomx) algo=rcpu ;;
  esac

  case "${algo,,}" in
    fishhashplus|x16rt|riecoin|v11|v12) backend=cuda ;;
    *) backend=cpu ;;
  esac
  [[ "$extra" =~ (^|[[:space:]])--backend([=[:space:]]|$) ]] && backend=""

  mkdir -p "$(dirname "$config")"
  {
    printf 'POOL=%q\n' "$pool"
    printf 'USER=%q\n' "$user"
    printf 'ALGO=%q\n' "$algo"
    printf 'PASS=%q\n' "$pass"
    printf 'BACKEND=%q\n' "$backend"
    printf 'EXTRA_ARGS=%q\n' "$extra"
  } > "$config"
}

# Critical HiveOS compatibility fix: h-config.sh is sourced by HiveOS and on
# installations that do not call miner_config_gen afterwards, the config must
# be generated during sourcing.
miner_config_gen
