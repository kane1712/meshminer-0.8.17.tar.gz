#!/usr/bin/env bash
set -o pipefail
cd "$(dirname "$0")"
CONFIG="${CUSTOM_CONFIG_FILENAME:-./meshminer.conf}"
[[ ! -f "$CONFIG" ]] && echo "MeshMiner config missing: $CONFIG" >&2 && exit 1
source "$CONFIG"
LOG="${CUSTOM_LOG_BASENAME:-/var/log/miner/meshminer/meshminer}.log"
mkdir -p "$(dirname "$LOG")"
chmod +x ./meshpool-miner
args=(--algo "$ALGO" --pool "$POOL" --user "$USER")
[[ -n "$BACKEND" ]] && args+=(--backend "$BACKEND")
[[ -n "$PASS" ]] && args+=(--pass "$PASS")
# CUSTOM_USER_CONFIG is intentionally shell-split so normal Hive extra args work.
if [[ -n "$EXTRA_ARGS" ]]; then
  read -r -a extra <<< "$EXTRA_ARGS"
  args+=("${extra[@]}")
fi
exec stdbuf -oL -eL ./meshpool-miner "${args[@]}" 2>&1 | tee -a "$LOG"
