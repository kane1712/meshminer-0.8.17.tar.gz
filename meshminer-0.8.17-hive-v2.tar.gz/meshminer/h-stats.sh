#!/usr/bin/env bash
# Sourced by Hive agent. MeshMiner has no HTTP API, so derive speed from recent log output.
log="${CUSTOM_LOG_BASENAME:-/var/log/miner/meshminer/meshminer}.log"
ver="0.8.17"
algo="${CUSTOM_ALGO:-unknown}"
[[ -f "${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/meshminer/meshminer.conf}" ]] && source "${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/meshminer/meshminer.conf}" 2>/dev/null && algo="${ALGO:-$algo}"

# Parse the most recent rate token such as 123.4 H/s, kH/s, MH/s, GH/s or c/s.
line=""; [[ -f "$log" ]] && line=$(tail -n 250 "$log" | grep -Eio '[0-9]+([.][0-9]+)?[[:space:]]*(k|m|g|t)?(h/s|hash/s|c/s)' | tail -1)
num=$(grep -Eo '^[0-9]+([.][0-9]+)?' <<< "$line" 2>/dev/null)
unit=$(sed -E 's/^[0-9.]+[[:space:]]*//' <<< "$line" | tr '[:upper:]' '[:lower:]')
mult=0; hsunit="hs"
case "$unit" in
  kh/s*|khash/s*) mult=1000; hsunit="khs" ;;
  mh/s*|mhash/s*) mult=1000000; hsunit="mhs" ;;
  gh/s*|ghash/s*) mult=1000000000; hsunit="ghs" ;;
  th/s*|thash/s*) mult=1000000000000; hsunit="ths" ;;
  h/s*|hash/s*) mult=1; hsunit="hs" ;;
  c/s*) mult=1; hsunit="hs" ;;
esac
[[ -z "$num" ]] && num=0
# Hive's $khs is always kH/s equivalent. Riecoin c/s is displayed numerically but is not a true hash rate.
khs=$(awk -v n="$num" -v m="$mult" 'BEGIN { if(m==0) print 0; else printf "%.6f", n*m/1000 }')

uptime=0
pid=$(pgrep -o -f '[m]eshpool-miner' 2>/dev/null)
[[ -n "$pid" && -r "/proc/$pid/stat" ]] && uptime=$(awk -v hz="$(getconf CLK_TCK)" -v up="$(cut -d. -f1 /proc/uptime)" '{print int(up-($22/hz))}' "/proc/$pid/stat" 2>/dev/null)

# Hardware arrays from Hive if available.
temps='[]'; fans='[]'; buses='[]'
if [[ -r /run/hive/gpu-stats.json ]] && command -v jq >/dev/null; then
  temps=$(jq -c '[.[]?.temp // empty]' /run/hive/gpu-stats.json 2>/dev/null); [[ -z "$temps" ]] && temps='[]'
  fans=$(jq -c '[.[]?.fan // empty]' /run/hive/gpu-stats.json 2>/dev/null); [[ -z "$fans" ]] && fans='[]'
fi
accepted=0; rejected=0
if [[ -f "$log" ]]; then
  accepted=$(grep -Eic 'accepted|share accepted' "$log" 2>/dev/null || true)
  rejected=$(grep -Eic 'rejected|share rejected|invalid share' "$log" 2>/dev/null || true)
fi
# One aggregate speed until MeshMiner exposes a machine-readable/per-GPU API.
stats=$(jq -nc --argjson hs "[$num]" --arg u "$hsunit" --argjson t "$temps" --argjson f "$fans" --argjson up "${uptime:-0}" --arg v "$ver" --arg a "$algo" --argjson ac "${accepted:-0}" --argjson rj "${rejected:-0}" '{hs:$hs,hs_units:$u,temp:$t,fan:$f,uptime:$up,ver:$v,ar:[$ac,$rj],algo:$a}')
