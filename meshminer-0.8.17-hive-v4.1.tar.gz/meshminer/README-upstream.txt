MeshPool Miner 0.8.17
===========================

A miner for MeshPool.

  Nonsense (NNN)     FishHashPlus, NVIDIA GPU
  Lumenite (LMT)     HomeScrypt v1.2, NVIDIA GPU or processor
  Plaine (PLNE)      Isochron, processor (a card can help)
  Dragonchain (DRGN) yespower, processor
  Avian (AVN)        two algorithms on one coin: X16RT on an NVIDIA GPU,
                     MinotaurX on the processor. Same address for both.
  RCPU (RCPU)        RandomX, processor
  Riecoin (RIC)      prime constellations, NVIDIA GPU (any Riecoin pool)


QUICK START
-----------

Nonsense:  edit start-nonsense.sh, set WALLET to your nonsense: address,
           save, and run it.

Lumenite:  the same with start-lumenite-v12.sh and your lmt1 address.

Plaine:    the same with start-plaine.sh and your plne1 address. A CPU
           coin; set BACKEND=both in the file to add an NVIDIA card.

Dragonchain: the same with start-dragonchain.sh and your dragon1
           address. CPU only.

RCPU:      the same with start-rcpu.sh and your rcpu1 address -- not a
           confidential rcpux1 address, which a block reward cannot pay.
           CPU only; the first start builds a 2 GB dataset (a few seconds).

Riecoin:   the same with start-riecoin.sh and your ric1q address. It
           mines on MeshPool (port 3349) by default, paid in the block's
           own coinbase; change POOL in the file for another Riecoin pool.
           The first start makes a prime table (under a second) and loads
           it onto the card.

Avian:     start-avian-x16rt.sh for the card, start-avian-minotaurx.sh
           for the processor, both with your R... address. A rig with a
           card and spare CPU can run both at once.

           Or start-avian-dual.sh, which mines BOTH at once in ONE
           miner: the card on X16RT and the processor on MinotaurX,
           paying the same address. See README-dual.txt.

That is all. There is nothing to install and no config file. The first
Nonsense start spends about fifteen seconds building a 4.5 GB dataset on
the card; that is normal.


WHAT IS IN HERE
---------------

  meshpool-miner        the miner
  start-nonsense.sh        mine Nonsense on MeshPool (port 3338)
  start-lumenite-v12.sh    mine Lumenite on MeshPool (port 3335)
  start-plaine.sh          mine Plaine on MeshPool (port 3342), CPU
  start-dragonchain.sh     mine Dragonchain on MeshPool (port 3340), CPU
  start-avian-x16rt.sh     mine Avian X16RT on MeshPool (port 3344), GPU
  start-avian-minotaurx.sh mine Avian MinotaurX on MeshPool (port 3345), CPU
  start-avian-dual.sh      mine BOTH Avian algorithms at once, one miner
  start-rcpu.sh            mine RCPU on MeshPool (port 3348), CPU
  start-riecoin.sh         mine Riecoin on MeshPool (port 3349), GPU
  README-dual.txt            how dual mining works, and two coins at once
  check-gpu.sh             verify your GPU computes correct hashes


REQUIREMENTS
------------

  Nonsense     NVIDIA card, RTX 20-series or newer, with at least 6 GB
               of memory (the dataset is 4.5 GB) and a current driver.
               No CUDA toolkit needed; the driver is enough.

  Lumenite     NVIDIA RTX 20-series or newer, or any 64-bit processor.

  RCPU         a 64-bit processor and about 2.3 GB of free memory
               (--randomx-light runs in 256 MB at a tenth of the speed).

  Riecoin      NVIDIA RTX 20-series or newer with at least 4 GB of
               memory (it uses about 2.7 GB).

  GTX 10-series and older cards are not supported.


OPTIONS
-------

  --pool a,b,c        fallback pools in order. If the first cannot be
                      reached the miner moves to the next, and checks
                      every minute whether a better one is back.
  --power 250         cap the card at 250 W. Needs administrator (root).
                      On HomeScrypt a 3080 Ti holds full speed at 250 W
                      and runs much cooler.
  --power auto        Riecoin only: find the limit by itself. It starts
                      at 3/4 of the card's default and adds 10 W a minute
                      while that still buys speed, stopping before 80 C or
                      a driver slowdown. The result is remembered per card;
                      --power retune starts over, --power-temp 75 sets a
                      lower ceiling. Needs administrator (root).
  --tune              Riecoin only: measure this card's best pipeline
                      settings. It reads the card (SMs, L2, shared memory)
                      and then times each setting for a few seconds, about
                      three minutes in all, mining nothing meanwhile. Done
                      by itself the first time a card is seen and remembered
                      by the card's name and power limit, so a changed limit
                      is measured again; --tune measures again, --no-tune
                      skips it, --tune 10 spends 10 s a setting.
                      --tune-verbose names each setting and, at the end,
                      prints the --ric-* flags that pin the result on any
                      machine.
  --ric-old-shares    Riecoin only: send only shares whose first five
                      numbers are prime in a row, as versions before 0.8.13
                      did, for a pool that still counts them that way.
                      MeshPool counts every share the chain's rule accepts.
  --device 0,1        mine on some cards only
  --fan auto          leave the fans to the driver
  --help              everything else


FEES
----

The miner takes a small fee by mining to the developer's address for a
slice of the time, shown in the banner and in pink while it happens:

  Nonsense    2% on MeshPool, 7% on other pools
  Lumenite    0.5% on MeshPool, 1.2% on other pools
  Avian       0.5% on MeshPool, 1% on other pools -- and on Avian the fee
              is mined on whichever pool you use, to the address shown
  the others  0.5% on MeshPool, 1.2% on other pools -- RCPU included
  Bitfuc, Korsh and Slithy Tove have no MeshPool pool, so their fee is
  mined on whichever pool you use, to the address shown, as on Avian.
  Slithy Tove's testnet mines free until its mainnet on 2026-11-01.

  Riecoin     no fee yet.

Nothing is hidden: the address and the rate are printed at every start.


RIECOIN: WHAT THE NUMBERS MEAN
------------------------------

Riecoin does not hash; the card tests numbers for being prime. The rate
is shown in c/s, candidates tested per second, and does not compare with
H/s on any other coin or with the "hashrate" on block explorers.

  tuples a/b/c/d/e/f/g   how often 1, 2, ... 7 primes in a row were found
  5 or 6 in a row        a share: shows the pool you are working
  7 in a row             a block, "full 7-tuple" in the log

Each step is about 20 times rarer than the one before. The stats line
also shows the card's temperature, power and clock: if the rate drops
while the temperature climbs, the card is throttling.
