#!/usr/bin/env bash
set -o pipefail
cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1
CONFIG="${CUSTOM_CONFIG_FILENAME:-./meshminer.conf}"
# Last-resort generation for Hive versions that did not generate/source the config beforehand.
if [[ ! -f "$CONFIG" ]]; then
  if [[ -f ./h-config.sh ]]; then
    # shellcheck disable=SC1091
    source ./h-config.sh
    declare -F miner_config_gen >/dev/null && miner_config_gen
  fi
fi
if [[ ! -f "$CONFIG" ]]; then
  echo "MeshMiner: config missing after generation attempt: $CONFIG" >&2
  echo "CUSTOM_URL=${CUSTOM_URL:-<empty>} CUSTOM_ALGO=${CUSTOM_ALGO:-<empty>} CUSTOM_TEMPLATE=${CUSTOM_TEMPLATE:+<set>}" >&2
  exit 1
fi
# shellcheck disable=SC1090
source "$CONFIG"
args=(--algo "$ALGO" --pool "$POOL" --user "$USER" --device "0,1,2,3,4,5,6,7,8,9,10,11")
[[ -n "$BACKEND" ]] && args+=(--backend "$BACKEND")
[[ -n "$PASS" ]] && args+=(--pass "$PASS")
if [[ -n "$EXTRA_ARGS" ]]; then read -r -a extra_arr <<< "$EXTRA_ARGS"; args+=("${extra_arr[@]}"); fi
chmod +x ./meshpool-miner
mkdir -p "$(dirname "${CUSTOM_LOG_BASENAME:-/var/log/miner/meshminer/meshminer}")"
echo "MeshMiner 0.8.17 starting"
printf 'Command: ./meshpool-miner'; printf ' %q' "${args[@]}"; printf '\n'
exec ./meshpool-miner "${args[@]}" 2>&1 | tee -a "${CUSTOM_LOG_BASENAME:-/var/log/miner/meshminer/meshminer}.log"
