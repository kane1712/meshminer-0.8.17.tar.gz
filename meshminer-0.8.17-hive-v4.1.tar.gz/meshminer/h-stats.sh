#!/usr/bin/env bash
# Conservative first-pass stats: do not break Hive agent if MeshMiner output changes by algorithm.
khs=0
stats="{\"hs\":[],\"hs_units\":\"hs\",\"temp\":[],\"fan\":[],\"uptime\":0,\"ver\":\"0.8.17\",\"algo\":\"${CUSTOM_ALGO:-custom}\"}"
