#!/usr/bin/env bash
set -o pipefail
cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1
CONFIG="${CUSTOM_CONFIG_FILENAME:-./meshminer.conf}"
# Last-resort generation for Hive versions that did not generate/source the config beforehand.
if [[ ! -f "$CONFIG" ]]; then
  if [[ -f ./h-config.sh ]]; then
    # shellcheck disable=SC1091
    source ./h-config.sh
    declare -F miner_config_gen >/dev/null && miner_config_gen
  fi
fi
if [[ ! -f "$CONFIG" ]]; then
  echo "MeshMiner: config missing after generation attempt: $CONFIG" >&2
  echo "CUSTOM_URL=${CUSTOM_URL:-<empty>} CUSTOM_ALGO=${CUSTOM_ALGO:-<empty>} CUSTOM_TEMPLATE=${CUSTOM_TEMPLATE:+<set>}" >&2
  exit 1
fi
# shellcheck disable=SC1090
source "$CONFIG"
args=(--algo "$ALGO" --pool "$POOL" --user "$USER")
[[ -n "$BACKEND" ]] && args+=(--backend "$BACKEND")
[[ -n "$PASS" ]] && args+=(--pass "$PASS")
if [[ -n "$EXTRA_ARGS" ]]; then read -r -a extra_arr <<< "$EXTRA_ARGS"; args+=("${extra_arr[@]}"); fi
chmod +x ./meshpool-miner
LOG_BASE="${CUSTOM_LOG_BASENAME:-/var/log/miner/meshminer/meshminer}"
mkdir -p "$(dirname "$LOG_BASE")"

echo "MeshMiner 0.8.17 starting - 12 GPU test"
pids=()
for device in {0..11}; do
  log="${LOG_BASE}-gpu${device}.log"
  printf '[GPU%s] Command: ./meshpool-miner' "$device"
  printf ' %q' "${args[@]}"
  printf ' --device %q\n' "$device"
  ./meshpool-miner "${args[@]}" --device "$device" > >(tee -a "$log" | sed -u "s/^/[GPU${device}] /") 2>&1 &
  pids+=("$!")
  sleep 1
done

cleanup() {
  echo "MeshMiner: stopping GPU processes"
  kill "${pids[@]}" 2>/dev/null || true
  wait "${pids[@]}" 2>/dev/null || true
}
trap cleanup INT TERM EXIT

# Keep the Hive custom miner process alive while the per-GPU miners run.
# If every child exits, return a failure so Hive can restart it.
while :; do
  alive=0
  for pid in "${pids[@]}"; do
    if kill -0 "$pid" 2>/dev/null; then
      alive=$((alive + 1))
    fi
  done
  if (( alive == 0 )); then
    echo "MeshMiner: all GPU processes exited" >&2
    exit 1
  fi
  sleep 5
done
