#!/usr/bin/env bash
miner_ver() { echo "0.8.17"; }
miner_config_echo() {
  local config="${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/meshminer/meshminer.conf}"
  [[ -f "$config" ]] && cat "$config" || echo "MeshMiner config has not been generated yet"
}
miner_config_gen() {
  local config="${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/meshminer/meshminer.conf}"
  local pool="${CUSTOM_URL%%$'\n'*}"; pool="${pool%% *}"
  pool="${pool#stratum+tcp://}"; pool="${pool#stratum://}"; pool="${pool#tcp://}"
  local user="${CUSTOM_TEMPLATE:-${CUSTOM_WALLET:-}}"
  local algo="${CUSTOM_ALGO:-}"
  local extra="${CUSTOM_USER_CONFIG//$'\n'/ }"
  local pass="${CUSTOM_PASS:-}"
  [[ -n "${WAL:-}" ]] && user="${user//%WAL%/$WAL}"
  [[ -n "${WORKER_NAME:-}" ]] && user="${user//%WORKER_NAME%/$WORKER_NAME}"
  [[ -z "$pool" ]] && { echo "MeshMiner: Pool URL is required" >&2; return 1; }
  [[ -z "$user" ]] && { echo "MeshMiner: Wallet/template is required" >&2; return 1; }
  [[ -z "$algo" ]] && { echo "MeshMiner: Hash algorithm is required" >&2; return 1; }
  local backend=cuda
  case "${algo,,}" in minotaurx|yespower|rcpu|randomx|isochron) backend=cpu ;; esac
  mkdir -p "$(dirname "$config")"
  { printf 'POOL=%q\n' "$pool"; printf 'USER=%q\n' "$user"; printf 'ALGO=%q\n' "$algo"; printf 'BACKEND=%q\n' "$backend"; printf 'PASS=%q\n' "$pass"; printf 'EXTRA_ARGS=%q\n' "$extra"; } > "$config"
}
if [[ -n "${CUSTOM_URL:-}" && -n "${CUSTOM_ALGO:-}" && -n "${CUSTOM_TEMPLATE:-${CUSTOM_WALLET:-}}" ]]; then
  miner_config_gen || return 1 2>/dev/null || exit 1
fi
