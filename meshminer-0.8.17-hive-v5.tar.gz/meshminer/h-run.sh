#!/usr/bin/env bash
set -o pipefail
cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1
CONFIG="${CUSTOM_CONFIG_FILENAME:-./meshminer.conf}"
if [[ ! -f "$CONFIG" ]]; then source ./h-config.sh; miner_config_gen || exit 1; fi
# shellcheck disable=SC1090
source "$CONFIG"
chmod +x ./meshpool-miner
LOGDIR="$(dirname "${CUSTOM_LOG_BASENAME:-/var/log/miner/meshminer/meshminer}")"
mkdir -p "$LOGDIR"
rm -f "$LOGDIR"/gpu*.log

# Remove core options from Extra Config so Hive fields remain authoritative.
read -r -a raw_extra <<< "${EXTRA_ARGS:-}"
extra=()
skip=0
for ((i=0; i<${#raw_extra[@]}; i++)); do
  t="${raw_extra[$i]}"
  if ((skip)); then skip=0; continue; fi
  case "$t" in
    --algo|--pool|--user|--backend|--device) skip=1 ;;
    --algo=*|--pool=*|--user=*|--backend=*|--device=*) ;;
    *) extra+=("$t") ;;
  esac
done

base=(--pool "$POOL" --user "$USER" --backend "$BACKEND" --algo "$ALGO")
[[ -n "$PASS" ]] && base+=(--pass "$PASS")
base+=("${extra[@]}")

mapfile -t gpus < <(nvidia-smi --query-gpu=index --format=csv,noheader,nounits 2>/dev/null | sed '/^[[:space:]]*$/d')
if [[ "$BACKEND" != "cuda" || ${#gpus[@]} -eq 0 ]]; then
  echo "MeshMiner 0.8.17 starting single process ($BACKEND)"
  printf 'Command: ./meshpool-miner'; printf ' %q' "${base[@]}"; printf '\n'
  exec ./meshpool-miner "${base[@]}"
fi

echo "MeshMiner 0.8.17 multi-GPU wrapper starting ${#gpus[@]} CUDA devices"
pids=()
cleanup() { trap - TERM INT EXIT; kill "${pids[@]}" 2>/dev/null; wait "${pids[@]}" 2>/dev/null; }
trap cleanup TERM INT EXIT
for gpu in "${gpus[@]}"; do
  logfile="$LOGDIR/gpu${gpu}.log"
  args=("${base[@]}" --device "$gpu")
  printf '[GPU%s] Command: ./meshpool-miner' "$gpu"; printf ' %q' "${args[@]}"; printf '\n'
  ( stdbuf -oL -eL ./meshpool-miner "${args[@]}" 2>&1 | sed -u "s/^/[GPU${gpu}] /" | tee -a "$logfile" ) &
  pids+=("$!")
  sleep 0.5
done
# Keep Hive's custom miner process alive while any child is mining.
while :; do
  alive=0
  for p in "${pids[@]}"; do kill -0 "$p" 2>/dev/null && ((alive++)); done
  ((alive == 0)) && { echo "MeshMiner: all GPU processes exited" >&2; exit 1; }
  sleep 5
done
