#!/usr/bin/env bash
LOGDIR="$(dirname "${CUSTOM_LOG_BASENAME:-/var/log/miner/meshminer/meshminer}")"
shopt -s nullglob
logs=("$LOGDIR"/gpu*.log)
hs=(); temps=(); fans=(); buses=()
total_hs=0; ac=0; rj=0

# GPU telemetry supplied by Hive, when available.
if [[ -n "${gpu_stats:-}" ]] && command -v jq >/dev/null 2>&1; then
  hive_temp=$(jq -c '.temp // []' <<<"$gpu_stats" 2>/dev/null)
  hive_fan=$(jq -c '.fan // []' <<<"$gpu_stats" 2>/dev/null)
  hive_bus=$(jq -c '.busids // []' <<<"$gpu_stats" 2>/dev/null)
fi

for log in "${logs[@]}"; do
  [[ -s "$log" ]] || continue
  gpu=$(basename "$log" | sed -n 's/^gpu\([0-9]\+\)\.log$/\1/p')
  line=$(grep -E '[0-9]+ c/s .*shares [0-9]+/[0-9]+' "$log" | tail -n1)
  rate=$(sed -nE 's/.*[^0-9]([0-9]+) c\/s.*/\1/p' <<<"$line")
  sharepair=$(grep -oE 'shares [0-9]+/[0-9]+' <<<"$line" | tail -n1 | awk '{print $2}')
  accepted=${sharepair%/*}; rejected=${sharepair#*/}
  [[ "$rate" =~ ^[0-9]+$ ]] || rate=0
  [[ "$accepted" =~ ^[0-9]+$ ]] || accepted=0
  [[ "$rejected" =~ ^[0-9]+$ ]] || rejected=0
  hs+=("$rate"); ((total_hs+=rate)); ((ac+=accepted)); ((rj+=rejected))
  if [[ -n "${hive_temp:-}" ]]; then
    temps+=("$(jq -r ".[$gpu] // null" <<<"$hive_temp")")
    fans+=("$(jq -r ".[$gpu] // null" <<<"$hive_fan")")
    bid=$(jq -r ".[$gpu] // null" <<<"$hive_bus")
    if [[ "$bid" != null ]]; then hex=${bid%%:*}; hex=${hex#0000:}; buses+=("$((16#$hex))"); else buses+=(null); fi
  else
    t=$(grep -oE '[0-9]+C' <<<"$line" | tail -n1 | tr -d C); temps+=("${t:-null}"); fans+=(null); buses+=(null)
  fi
done

# During autotune/no summary yet, preserve one zero slot per launched GPU.
if ((${#hs[@]} == 0)) && ((${#logs[@]} > 0)); then
  for _ in "${logs[@]}"; do hs+=(0); temps+=(null); fans+=(null); buses+=(null); done
fi
khs=$(awk -v h="$total_hs" 'BEGIN { printf "%.6f", h/1000 }')
uptime=0
if ((${#logs[@]} > 0)); then first=${logs[0]}; [[ -e "$first" ]] && uptime=$(( $(date +%s) - $(stat -c %Y "$first") )); fi
if command -v jq >/dev/null 2>&1; then
  hs_json=$(printf '%s\n' "${hs[@]}" | jq -cs 'map(tonumber)')
  temp_json=$(printf '%s\n' "${temps[@]}" | jq -Rsc 'split("\n")[:-1] | map(if .=="null" then null else tonumber end)')
  fan_json=$(printf '%s\n' "${fans[@]}" | jq -Rsc 'split("\n")[:-1] | map(if .=="null" then null else tonumber end)')
  bus_json=$(printf '%s\n' "${buses[@]}" | jq -Rsc 'split("\n")[:-1] | map(if .=="null" then null else tonumber end)')
  stats=$(jq -nc --argjson hs "$hs_json" --argjson temp "$temp_json" --argjson fan "$fan_json" --argjson bus "$bus_json" --argjson ac "$ac" --argjson rj "$rj" --argjson uptime "$uptime" --arg algo "${CUSTOM_ALGO:-riecoin}" '{hs:$hs,hs_units:"hs",temp:$temp,fan:$fan,uptime:$uptime,ver:"0.8.17",ar:[$ac,$rj],algo:$algo,bus_numbers:$bus}')
else
  stats=""
fi
