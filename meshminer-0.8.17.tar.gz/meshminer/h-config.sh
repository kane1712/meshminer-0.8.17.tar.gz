#!/usr/bin/env bash
miner_ver() { echo "0.8.17"; }
miner_config_echo() {
  [[ -f "$CUSTOM_CONFIG_FILENAME" ]] && cat "$CUSTOM_CONFIG_FILENAME" || echo "MeshMiner config has not been generated yet"
}
miner_config_gen() {
  local config="${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/meshminer/meshminer.conf}"
  local pool="${CUSTOM_URL%%$'\n'*}"
  pool="${pool%% *}"
  pool="${pool#stratum+tcp://}"; pool="${pool#stratum://}"; pool="${pool#tcp://}"
  local user="${CUSTOM_TEMPLATE:-${CUSTOM_WALLET:-}}"
  local algo="${CUSTOM_ALGO:-}"
  local extra="${CUSTOM_USER_CONFIG//$'\n'/ }"
  local pass="${CUSTOM_PASS:-}"
  [[ -z "$pool" ]] && { echo "MeshMiner: Pool URL is required" >&2; return 1; }
  [[ -z "$user" ]] && { echo "MeshMiner: Wallet/template is required" >&2; return 1; }
  [[ -z "$algo" ]] && { echo "MeshMiner: Hash algorithm is required" >&2; return 1; }
  # MeshMiner is CUDA for these GPU algorithms; CPU for known CPU algorithms.
  local backend=cuda
  case "${algo,,}" in minotaurx|yespower|rcpu|randomx) backend=cpu ;; isochron) backend=cpu ;; esac
  # User can override the default backend in Extra config.
  if [[ " $extra " == *" --backend "* || " $extra " == *" --backend="* ]]; then backend=""; fi
  mkdir -p "$(dirname "$config")"
  {
    printf 'POOL=%q\n' "$pool"
    printf 'USER=%q\n' "$user"
    printf 'ALGO=%q\n' "$algo"
    printf 'BACKEND=%q\n' "$backend"
    printf 'PASS=%q\n' "$pass"
    printf 'EXTRA_ARGS=%q\n' "$extra"
  } > "$config"
  chmod 644 "$config"
}
