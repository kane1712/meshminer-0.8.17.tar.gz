#!/usr/bin/env bash
set -o pipefail
cd "$(dirname "${BASH_SOURCE[0]}")" || exit 1
CONFIG="${CUSTOM_CONFIG_FILENAME:-./meshminer.conf}"
if [[ ! -f "$CONFIG" ]]; then echo "MeshMiner: config missing: $CONFIG" >&2; exit 1; fi
# shellcheck disable=SC1090
source "$CONFIG"
args=(--algo "$ALGO" --pool "$POOL" --user "$USER")
[[ -n "$BACKEND" ]] && args+=(--backend "$BACKEND")
[[ -n "$PASS" ]] && args+=(--pass "$PASS")
# Extra config is intentionally shell-split so Hive users can supply normal CLI switches.
if [[ -n "$EXTRA_ARGS" ]]; then read -r -a extra_arr <<< "$EXTRA_ARGS"; args+=("${extra_arr[@]}"); fi
chmod +x ./meshpool-miner
mkdir -p "$(dirname "${CUSTOM_LOG_BASENAME:-/var/log/miner/meshminer/meshminer}")"
echo "MeshMiner 0.8.17 starting"
printf 'Command: ./meshpool-miner'; printf ' %q' "${args[@]}"; printf '\n'
exec ./meshpool-miner "${args[@]}" 2>&1 | tee -a "${CUSTOM_LOG_BASENAME:-/var/log/miner/meshminer/meshminer}.log"
